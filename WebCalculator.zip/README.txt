
Java Web Calculator
===================

How to run:
1. Make sure you have Java 11 or newer installed.
2. Open a terminal (Command Prompt or PowerShell on Windows).
3. Navigate to the folder containing WebCalculator.jar
4. Run the command:
   java -jar WebCalculator.jar
5. Open your web browser and go to http://localhost:8080

Enjoy your Java web calculator!
